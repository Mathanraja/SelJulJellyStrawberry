package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class CreateLeadPage extends BaseClass{
public CreateLeadPage enterCompanyName() {
	driver.findElementById("createLeadForm_companyName").sendKeys("Testleaf");
	return this;
}
public CreateLeadPage enterFirstName() {
		driver.findElementById("createLeadForm_firstName").sendKeys("Balaji");
		return this;
}
public CreateLeadPage enterLastName() {
	driver.findElementById("createLeadForm_lastName").sendKeys("Chandrasekaran");
	return this;
}
public ViewLeadPage clickCreateLeadButton() {
		driver.findElementByClassName("smallSubmit").click();
		return new ViewLeadPage();
}
}
