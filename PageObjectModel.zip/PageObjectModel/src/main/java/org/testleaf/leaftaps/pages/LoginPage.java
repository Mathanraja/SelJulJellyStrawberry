package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class LoginPage extends BaseClass{
public LoginPage enterUsername() {
	driver.findElementById("username").sendKeys("Demosalesmanager");
	return this;
}
public LoginPage enterPassword() {
	driver.findElementById("password").sendKeys("crmsfa");
	return this;
}
public HomePage clickLoginButton() {
	driver.findElementByClassName("decorativeSubmit").click();
	return new HomePage();
}
}
