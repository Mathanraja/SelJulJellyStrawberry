package org.testleaf.leaftaps.testcases;

import org.testleaf.leaftaps.base.BaseClass;
import org.testleaf.leaftaps.pages.LoginPage;
import org.testng.annotations.Test;

public class TC001_CreateLead extends BaseClass{
	
	@Test(dataProvider = "") public void runTC001(String username) {
		/*
		 * LoginPage page = new LoginPage();
		 *  page.enterUsername(); 
		 *  page.enterPassword();
		 * page.clickLoginButton();
		 */
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.clickCreateLeadButton()
		.verifyLeadCreation();
		
		
		
	
		
		
		
		
		
	}

}
