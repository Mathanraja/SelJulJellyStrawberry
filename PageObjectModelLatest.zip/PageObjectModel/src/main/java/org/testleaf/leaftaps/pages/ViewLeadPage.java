package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class ViewLeadPage extends BaseClass{
public ViewLeadPage verifyLeadCreation() {
	System.out.println("Verified");
	return this;
}
}
