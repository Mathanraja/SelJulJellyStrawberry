package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class LoginPage extends BaseClass{
public LoginPage enterUsername(String dataUsername) {
	driver.findElementById("username").sendKeys(dataUsername);
	return this;
}
public LoginPage enterPassword(String dataPassword) {
	driver.findElementById("password").sendKeys(dataPassword);
	return this;
}
public HomePage clickLoginButton() {
	driver.findElementByClassName("decorativeSubmit").click();
	return new HomePage();
}
}
