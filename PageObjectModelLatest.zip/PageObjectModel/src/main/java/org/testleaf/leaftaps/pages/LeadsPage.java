package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class LeadsPage extends BaseClass{
public CreateLeadPage clickCreateLeadLink() {
	driver.findElementByLinkText("Create Lead").click();
	return new CreateLeadPage();
}
}
