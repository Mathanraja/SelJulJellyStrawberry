package org.testleaf.leaftaps.testcases;

import org.testleaf.leaftaps.base.BaseClass;
import org.testleaf.leaftaps.pages.LoginPage;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC001_CreateLead extends BaseClass{
	@BeforeTest
	public void setData() {
		excelfilename="TC001";
	}
	
	@Test(dataProvider = "excelData") public void runTC001(String username,String password, String companyName, String firstName, String lastName) {
		/*
		 * LoginPage page = new LoginPage();
		 *  page.enterUsername(); 
		 *  page.enterPassword();
		 * page.clickLoginButton();
		 */
		
		new LoginPage()
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLeadButton()
		.verifyLeadCreation();
		
		
		
	
		
		
		
		
		
	}

}
