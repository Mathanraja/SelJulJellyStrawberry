package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class MyHomePage extends BaseClass{
public LeadsPage clickLeadsLink() {
	driver.findElementByLinkText("Leads").click();
	return new LeadsPage();
}
}
