package org.testleaf.leaftaps.pages;

import org.testleaf.leaftaps.base.BaseClass;

public class CreateLeadPage extends BaseClass{
public CreateLeadPage enterCompanyName(String dataCName) {
	driver.findElementById("createLeadForm_companyName").sendKeys(dataCName);
	return this;
}
public CreateLeadPage enterFirstName(String dataFName) {
		driver.findElementById("createLeadForm_firstName").sendKeys(dataFName);
		return this;
}
public CreateLeadPage enterLastName(String dataLName) {
	driver.findElementById("createLeadForm_lastName").sendKeys(dataLName);
	return this;
}
public ViewLeadPage clickCreateLeadButton() {
		driver.findElementByClassName("smallSubmit").click();
		return new ViewLeadPage();
}
}
